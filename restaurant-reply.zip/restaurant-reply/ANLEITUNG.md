# 🚀 RestaurantReply – Deine Webseite online stellen

Diese Anleitung bringt deine Webseite in ca. **30–45 Minuten** ins Internet.
Du brauchst KEINE Programmierkenntnisse – nur genau den Schritten folgen.

Am Ende hast du eine echte Adresse wie `restaurant-reply.vercel.app`,
die du jedem Restaurant zeigen kannst.

---

## 📋 Was du brauchst (alles kostenlos zum Anmelden)

1. Eine **E-Mail-Adresse**
2. Ein **GitHub-Konto** (zum Speichern des Codes)
3. Ein **Vercel-Konto** (zum Hosten der Webseite)
4. Einen **Anthropic API-Schlüssel** (das kostet ein paar Cent pro Nutzung)

---

## Schritt 1: Anthropic API-Schlüssel holen 🔑

Das ist der Schlüssel, mit dem deine Webseite die KI nutzen darf.

1. Gehe auf **https://console.anthropic.com**
2. Erstelle ein Konto (oder logge dich ein)
3. Lade etwas Guthaben auf (Minimum ist meist 5 $) unter **"Billing"** / **"Plans & Billing"**
4. Klicke links auf **"API Keys"** → **"Create Key"**
5. Gib ihm einen Namen (z.B. "RestaurantReply") und kopiere den Schlüssel
   - Er beginnt mit `sk-ant-...`
   - ⚠️ **WICHTIG:** Speichere ihn sofort irgendwo (z.B. Notizen). Er wird nur EINMAL angezeigt!

> 💡 Kosten: Jede generierte Antwort kostet nur Bruchteile eines Cents.
> Mit 5 $ Guthaben kommst du bei normaler Nutzung sehr lange aus.

---

## Schritt 2: Code zu GitHub hochladen 📦

1. Gehe auf **https://github.com** und erstelle ein kostenloses Konto
2. Klicke oben rechts auf **"+"** → **"New repository"**
3. Name: `restaurant-reply` → **"Create repository"**
4. Auf der nächsten Seite klicke auf **"uploading an existing file"**
5. Ziehe **ALLE Dateien aus dem `restaurant-reply`-Ordner** in das Fenster
   - WICHTIG: Lade auch die Unterordner `app` und `app/api/generate` mit hoch
   - Lade NICHT den Ordner `node_modules` hoch (falls vorhanden)
6. Klicke unten auf **"Commit changes"**

---

## Schritt 3: Auf Vercel veröffentlichen 🌐

1. Gehe auf **https://vercel.com**
2. Klicke auf **"Sign Up"** und wähle **"Continue with GitHub"**
   (so sind beide Konten verbunden)
3. Nach dem Login: **"Add New..."** → **"Project"**
4. Suche dein `restaurant-reply` Repository und klicke **"Import"**
5. **BEVOR du auf Deploy klickst:** Öffne den Bereich **"Environment Variables"**
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** dein Schlüssel von Schritt 1 (`sk-ant-...`)
   - Klicke **"Add"**
6. Jetzt klicke **"Deploy"** 🎉
7. Warte 1–2 Minuten. Fertig!

Vercel zeigt dir nun deine Adresse, z.B. `restaurant-reply-xyz.vercel.app`

---

## ✅ Testen

Öffne deine neue Adresse im Browser. Gib testweise eine Bewertung ein und klick auf
"Antworten generieren". Wenn drei Antworten erscheinen → **es funktioniert!**

---

## 🛠️ Fehlerbehebung

**"Fehler beim Generieren":**
- Prüfe in Vercel unter Settings → Environment Variables, ob `ANTHROPIC_API_KEY` korrekt eingetragen ist (keine Leerzeichen!)
- Prüfe, ob auf deinem Anthropic-Konto Guthaben ist
- Nach dem Ändern einer Variable: in Vercel unter "Deployments" das neueste Deployment neu starten ("Redeploy")

**Seite lädt nicht / Build-Fehler:**
- Stelle sicher, dass die Ordnerstruktur stimmt: `app/page.js`, `app/layout.js`, `app/api/generate/route.js`

---

## 💰 Eigene Domain (optional, später)

Wenn du es noch professioneller willst, kannst du in Vercel unter
**Settings → Domains** eine eigene Adresse wie `restaurant-reply.de` verbinden
(eine Domain kostet ca. 10 €/Jahr).

---

## 📣 Nächster Schritt: Verkaufen

Jetzt hast du etwas Echtes zum Vorzeigen! Geh zu Restaurants in Sachsenhausen,
zeig die Seite auf dem Handy und biete sie für 20–50 €/Monat an.

Viel Erfolg! 🍀
